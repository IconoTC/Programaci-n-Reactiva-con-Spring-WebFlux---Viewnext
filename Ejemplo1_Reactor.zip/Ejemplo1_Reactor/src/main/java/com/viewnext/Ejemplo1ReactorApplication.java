package com.viewnext;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.viewnext.models.Producto;
import com.viewnext.models.ProductoTiendas;
import com.viewnext.models.Tiendas;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

@SpringBootApplication
public class Ejemplo1ReactorApplication implements CommandLineRunner{
	
	List<Producto> lista = Arrays.asList(
			new Producto(1, "Pantalla", 129.50),
			new Producto(2, "Raton", 32.50),
			new Producto(3, "Teclado", 57.95));

	// 1º en ejecutarse, levanta el contexto de Spring .....
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo1ReactorApplication.class, args);
	}

	// 2º en ejecutarse
	@Override
	public void run(String... args) throws Exception {
		contrapresion_backpressure2();
	}
	
	public void contrapresion_backpressure2(){
		// 2ª forma: Manejar la contrapresion pidiendo de 5 en 5
		// No aparece el mismo resultado porque lo maneja de forma distinta
		// pero lo importante es que no recibimos todo de golpe sino por bloques
		Flux.range(1, 20)
			.log()
			.limitRate(5)   // solicita 5, 4, 4, 4, 4   when 75% of the prefetch amount has been emitted.
			.subscribe(System.out::println);	
	}
	
	public void contrapresion_backpressure(){
		// Por defecto, cada vez que nos subscribimos a un Observable
		// le estamos pidiendo que envie todos los elementos que pueda a la vez.
		// La contrapresion consiste en poder decir el subscriptor al Publisher
		// cuantos elementos puede recibir para evitar la sobrecarga.
//		Flux.range(1, 20)
//			.log()
//			.subscribe(System.out::println);
		
		// request(unbounded) es ilimitado y nos ha enviado los 20 numeros a la vez
		
		// 1ª forma: Manejar la contrapresion pidiendo de 5 en 5
		// Modificar el subscriber
		Flux.range(1, 20)
			.log()
			.subscribe(new Subscriber<Integer>() {
				
				private Subscription subscription;
				
				private Integer limite = 5;
				private Integer contador = 0;

				@Override
				public void onSubscribe(Subscription s) {
					this.subscription = s;
					
					// Pedimos los primeros 5 elementos
					subscription.request(limite);
				}

				@Override
				public void onNext(Integer num) {
					// Aqui procesamos los elementos que recibimos
					System.out.println(num);
					contador++;
					if (contador == limite) {
						contador = 0;
						
						// Pedir los siguientes 5 elementos
						subscription.request(limite);
					}
				}

				@Override
				public void onError(Throwable t) {
					t.printStackTrace();
				}

				@Override
				public void onComplete() {
					System.out.println("------ FIN ------");
				}
				
			});
	}
	
	public void operador_create() {
		// Crear un flujo que emite datos cada medio segundo, transcurrido el primer segundo
		// Queremos que sea infinito
//		Flux.create(emitter -> {
//			Timer timer = new Timer();
//			timer.schedule(new TimerTask() {
//				
//					private int contador = 0;
//					
//					@Override
//					public void run() {
//						contador++;
//						emitter.next(contador);
//					}
//				}, 1000, 500);
//			})
//			.doOnNext(System.out::println)
//			.subscribe();
		
		// Lo queremos parar cuando llegue a 20
		Flux.create(emitter -> {
			Timer timer = new Timer();
			timer.schedule(new TimerTask() {
				
					private int contador = 0;
					
					@Override
					public void run() {
						// Si el contador es 20 finalizamos el timer y el emitter
						if (contador == 20) {
							timer.cancel();
							emitter.complete();
						}
						
						contador++;
						emitter.next(contador);
					}
				}, 1000, 500);
			})
			.doOnNext(System.out::println)
			.subscribe();
	}
	
	public void retardos_delay() throws InterruptedException {
		Flux<Integer> numeros = Flux.range(1, 10);
		Flux<Long> delay = Flux.interval(Duration.ofSeconds(1));
		
//		numeros.zipWith(delay, (num,retardo) -> num)
//			.doOnNext(System.out::println)
//			.subscribe();
		
		// El retardo hace que el metodo termine sin que le tiempo a recibir los numeros
		// 1ª solucion:
		//Thread.sleep(11_000);
		
		// 2ª solucion:
		numeros.zipWith(delay, (num,retardo) -> num)
			.doOnNext(System.out::println)
			.blockLast();   // Bloqueo hasta que llegue el ultimo dato
	}
	
	public void ejercicio1() {
		// Crear un flujo con numeros del 1 al 10
		// Crear otro flujo con numeros del 21 al 30
		Flux<Integer> numeros1 = Flux.range(1, 10);
		Flux<Integer> numeros2 = Flux.range(21, 10);
		
		// Combinar ambos flujos devolviendo la suma  1 + 21, 2 + 22, ...... 10 + 30
		
		// 1ª forma con zipWith
		numeros1.zipWith(numeros2, (n1, n2) -> new Integer(n1 + n2))
			.subscribe(System.out::println);
		
		// 2ª forma con zipWith
		numeros1.zipWith(numeros2)
			.map(tupla -> {
				Integer n1 = tupla.getT1();
				Integer n2 = tupla.getT2();
				return new Integer(n1 + n2);
			})
			.subscribe(System.out::println);
		
		// con flatMap
		numeros1.flatMap(it -> numeros2
				.skip(it-1)
				.take(1)
				.map(it2 -> it + it2))
		.subscribe(System.out::println);
	}
	
	public void operador_range() {
		Flux<Integer> numeros = Flux.range(10, 5);   // empieza en 10 y 5 elementos (10,11,12,13 y 14)
		numeros.subscribe(System.out::println);
	}
	
	public void combinar_flujos_zipWith() {	
		// Creamos un Mono con un producto
		Mono<Producto> productoMono = Mono.just(new Producto(1, "Pantalla", 129.50));
		
		// Crear un Mono de tiendas
		Mono<Tiendas> tiendasProductoMono = Mono.fromCallable(() -> {
			Tiendas tiendas = new Tiendas();
			tiendas.addTienda("PC Components");
			tiendas.addTienda("Amazon");
			tiendas.addTienda("Media Mark");
			return tiendas;
		});
		
		// Combinar ambos flujos para obtener un tercero
		productoMono.zipWith(tiendasProductoMono, (prod,tiendas) -> new ProductoTiendas(prod, tiendas))
			.subscribe(System.out::println);
		
		// Otra forma de hacerlo
		 Mono<Tuple2<Producto, Tiendas>> monoTupla = productoMono.zipWith(tiendasProductoMono);
		 monoTupla.map(tupla -> {
			 Producto prod = tupla.getT1();
			 Tiendas tiendas = tupla.getT2();
			 return new ProductoTiendas(prod, tiendas);   // Mono<ProductoTiendas>
		 })
		 .subscribe(System.out::println);		
	}
	
	
	public void combinar_flujos_flatMap() {	
		// Creamos un Mono con un producto
		Mono<Producto> productoMono = Mono.just(new Producto(1, "Pantalla", 129.50));
		
		// Crear un Mono de tiendas
		Mono<Tiendas> tiendasProductoMono = Mono.fromCallable(() -> {
			Tiendas tiendas = new Tiendas();
			tiendas.addTienda("PC Components");
			tiendas.addTienda("Amazon");
			tiendas.addTienda("Media Mark");
			return tiendas;
		});
		
		// Combinar ambos flujos para obtener un tercero
		productoMono.flatMap(prod -> tiendasProductoMono.map(tiendas -> new ProductoTiendas(prod, tiendas)))
			.subscribe(System.out::println);
		
	}
	
	public void convertir_flux_mono() {
		// De esta forma mostramos toda la lista como un solo objeto
		Flux.fromIterable(lista)
			.collectList()   // retorna Mono<List<Producto>>
			.subscribe(System.out::println);
		
		// Mostramos los productos de uno en uno
		Flux.fromIterable(lista)
		.collectList()   // retorna Mono<List<Producto>>
		.subscribe(listaProd -> listaProd.forEach(System.out::println));
		
	}
	
	public void operador_flatMap() {
		// El operador map modifica un elemento y lo devuelve al stream pero no es reactivo
		// flatMap modifica el elemento y lo devuelve como reactivo, un observable Flux o Mono
		Flux.fromIterable(lista)
			.flatMap(prod -> {
				if (prod.getDescripcion().equals("Raton"))
					return Mono.just(prod);
				else
					return Mono.empty();
			})
			.subscribe(prod -> System.out.println(prod));
	}
	
	public void operadores_map_filter() {
		// Crear un flujo a partir de un iterable
		// OJO!! Los arrays no son iterables
		
		Flux.fromIterable(lista)
			.filter(p -> p.getPrecio() > 50)  // filtra elementos en base a una condicion
			.map(prod -> {  // Modifica un elemento y lo devuelve al flujo
				prod.setDescripcion(prod.getDescripcion().toUpperCase());
				return prod;
			})
			.doOnNext(System.out::println) 
			.subscribe();
	}


	public void complete() {
		// Crear un flujo de datos y mostrar cada uno en la consola y un mensaje final
		Flux<String> datos = Flux.just("uno", "dos", "tres", "cuatro");
		
		// Si quiero meter un Runnable la unica opcion es tener 2 consumer:
		// 1.º muestra el dato por consola
		// 2.º es null
		datos.subscribe(dato -> System.out.println(dato), null, new Runnable() {
			
			// Este metodo run se ejecuta al terminar de procesar todo el flujo
			@Override
			public void run() {
				System.out.println(" --- FIN --- ");
				
			}
		});
		
		// Otra forma
		Flux<String> datos2 = Flux.just("uno", "dos", "tres", "cuatro")
				.doOnNext(System.out::println)
				.doOnComplete(new Runnable() {
			
			// Este metodo run se ejecuta al terminar de procesar todo el flujo
			@Override
			public void run() {
				System.out.println(" --- FIN --- ");
				
			}
		});
		datos2.subscribe();
	}
	
	public void crear_Flujo() {
		// Crear un flujo de datos y mostrar cada uno en la consola
//		Flux<String> datos = Flux.just("uno", "dos", "tres", "cuatro")
//				.doOnNext(dato -> System.out.println(dato));
		
		// Java 8
//		Flux<String> datos = Flux.just("uno", "dos", "tres", "cuatro")
//				.doOnNext(System.out::println);
		
		// Manejar excepciones
		Flux<String> datos = Flux.just("uno", "dos", "", "tres", "cuatro")
				.doOnNext(dato -> {
					if (dato.isEmpty()) {
						throw new RuntimeException("Dato vacio");
					}
					System.out.println(dato);
				});
		
		// Hasta que no se subscribe al flujo, no hace nada
		datos.subscribe();
	}

}
