package es.indra.persistence;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import es.indra.models.Carrito;
import reactor.core.publisher.Mono;

public interface CarritosDAO extends ReactiveMongoRepository<Carrito, String>{

	// URL para ver todos los carritos
	// http://localhost:8003/carritos
	
	// http://localhost:8003/carritos/search/findByUsuario?usuario=Pepito
	public Mono<Carrito> findByUsuario(String usuario);
}
