package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import es.indra.models.Carrito;
import es.indra.models.Pedido;
import es.indra.persistence.CarritosDAO;
import reactor.core.publisher.Mono;

@Service
public class CarritoBSImpl implements ICarritoBS{
	
	@Autowired
	private CarritosDAO dao;
	
	@Autowired
	private WebClient webClient;

	@Override
	public Mono<Carrito> crear(String usuario) {
		Carrito carrito = new Carrito();
		carrito.setUsuario(usuario);
		return dao.save(carrito);
	}

	@Override
	public Mono<Carrito> consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Mono<Carrito> agregarPedido(Long id, Integer cantidad, String usuario) {
		Mono<Pedido> monoPedido = webClient
				.get().uri("/crear/{id}/cantidad/{cantidad}", id, cantidad)
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToMono(Pedido.class);

		Mono<Carrito> monoCarrito = consultar(usuario);
		
		return monoPedido.zipWith(monoCarrito)  // Mono<Tuple2<Pedido, Carrito>
				.map(tupla -> {
					Pedido p = tupla.getT1();
					Carrito c = tupla.getT2();
					c.getContenido().add(p);
					c.setImporte(c.getImporte() + p.getProducto().getPrecio() * p.getCantidad());
					return c;   
				})
				.flatMap(c -> dao.save(c)); // Mono<Carrito>
	}

	@Override
	public Mono<Carrito> eliminarPedido(Long id, String usuario) {
		return consultar(usuario)
				.map(c -> {
					Carrito carrito = c.getContenido().stream()
						.filter(ped -> ped.getProducto().getID() == id)
						.map(ped -> {
							double precio = ped.getProducto().getPrecio();
							int cantidad = ped.getCantidad();
							c.setImporte(c.getImporte() - (cantidad * precio));
							return c;
						})
						.findFirst().get();
					carrito.getContenido().removeIf(pedido -> pedido.getProducto().getID() == id);
					return c;
				})
				.flatMap(c -> dao.save(c)); // Mono<Carrito>
	}
}









