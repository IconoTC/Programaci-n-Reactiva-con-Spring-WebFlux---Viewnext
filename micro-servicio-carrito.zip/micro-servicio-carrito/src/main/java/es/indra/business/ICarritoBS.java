package es.indra.business;

import es.indra.models.Carrito;
import reactor.core.publisher.Mono;

public interface ICarritoBS {
	
	Mono<Carrito> crear(String usuario);
	Mono<Carrito> agregarPedido(Long id, Integer cantidad, String usuario);
	Mono<Carrito> consultar(String usuario);
	Mono<Carrito> eliminarPedido(Long id, String usuario);

}
