package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import es.indra.business.ICarritoBS;
import es.indra.models.Carrito;
import reactor.core.publisher.Mono;

@Component
public class HandlerCarrito {
	
	@Autowired
	private ICarritoBS service;
	
	public Mono<ServerResponse> crear(ServerRequest request){
		return service.crear(request.pathVariable("usuario"))
				.flatMap(c -> ServerResponse.ok()
							.contentType(MediaType.APPLICATION_JSON)
							.body(Mono.just(c), Carrito.class))
				.switchIfEmpty(ServerResponse.notFound()
				.build());
	}
	
	public  Mono<ServerResponse> consultar(ServerRequest request){
		return service.consultar(request.pathVariable("usuario"))
				.flatMap(c -> ServerResponse.ok()
							.contentType(MediaType.APPLICATION_JSON)
							.body(Mono.just(c), Carrito.class))
				.switchIfEmpty(ServerResponse.notFound()
				.build());
	}
	
	public Mono<ServerResponse> agregarPedido(ServerRequest request){
		long id = Long.parseLong(request.pathVariable("id"));
		int cantidad = Integer.parseInt(request.pathVariable("cantidad"));
		String usuario = request.pathVariable("usuario");
		
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON)
				.body(service.agregarPedido(id, cantidad, usuario), Carrito.class);
	}
	
	public Mono<ServerResponse> eliminarPedido(ServerRequest request){
		long id = Long.parseLong(request.pathVariable("id"));
		String usuario = request.pathVariable("usuario");
		
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON)
				.body(service.eliminarPedido(id, usuario), Carrito.class);
	}

}







