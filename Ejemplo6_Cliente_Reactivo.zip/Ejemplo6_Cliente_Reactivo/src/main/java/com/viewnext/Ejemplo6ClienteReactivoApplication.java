package com.viewnext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.viewnext.business.IAlumnosBS;
import com.viewnext.models.Alumno;

@SpringBootApplication
public class Ejemplo6ClienteReactivoApplication implements CommandLineRunner{
	
	@Autowired
	private IAlumnosBS bs;
	
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo6ClienteReactivoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("----- Todos los alumnos -----");
		bs.consultarTodos()
			.subscribe(System.out::println);
			
		bs.buscarAlumno(3)
			.subscribe(alum -> {
				System.out.println("----- Buscar un alumno -----");
				System.out.println(alum);
			});
		
		
		bs.crearNuevo(new Alumno("Pepito", "Perez", 7.3))
			.subscribe(alum -> {
				System.out.println("----- Crear un alumno -----");
				System.out.println(alum);
			});
		
		
		bs.modificarAlumno(new Alumno(5, "Pepito", "Perez", 10))
			.subscribe(alum -> {
				System.out.println("----- Modificar un alumno -----");
				System.out.println(alum);
			});
		
	}

}
