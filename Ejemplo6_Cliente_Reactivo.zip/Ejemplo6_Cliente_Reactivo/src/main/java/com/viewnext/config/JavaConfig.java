package com.viewnext.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class JavaConfig {

	// En Spring como cliente de un servicio REST podemos utilizar:
	// - RestTemplate, pertenece a Spring MVC
	// - Feign, pertenece a Spring Cloud (es el que se utiliza en microservicios)
	// Ninguno de los 2 es reactivo.

	// El programacion reactiva utilizamos WebClient que pertenece a Spring WebFlux
	@Bean
	public WebClient webClient() {
		return WebClient.create("http://localhost:8081/api");
	}

}
