package com.viewnext.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.models.Alumno;
import com.viewnext.services.IAlumnosService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api")   // http://localhost:8081/api
public class AlumnosREST {
	
	@Autowired
	private IAlumnosService service;
	
	// http://localhost:8081/api/alumnos
	@GetMapping("/alumnos")
	public Flux<Alumno> todos(){
		return service.consultarTodos();
	}
	
	// http://localhost:8081/api/alumnos/2
	@GetMapping("/alumnos/{codigo}")
	public Mono<Alumno> consultarAlumno(@PathVariable(name = "codigo") int id){
		return service.buscarAlumno(id);
	}
	
	// http://localhost:8081/api/alumnos
	@PostMapping("/alumnos")
	public Mono<Alumno> insertarNuevo(@RequestBody Alumno alumno){
		return service.crearNuevo(alumno);
	}
	
	// http://localhost:8081/api/alumnos/2
	@DeleteMapping("/alumnos/{codigo}")
	public Mono<Void> borrarAlumno(@PathVariable(name = "codigo") int id){
		return service.eliminarAlumno(id);
	}
	
	// http://localhost:8081/api/alumnos
	@PutMapping("/alumnos")
	public Mono<Alumno> modificar(@RequestBody Alumno alumno){
		return service.modificarAlumno(alumno);
	}

}
