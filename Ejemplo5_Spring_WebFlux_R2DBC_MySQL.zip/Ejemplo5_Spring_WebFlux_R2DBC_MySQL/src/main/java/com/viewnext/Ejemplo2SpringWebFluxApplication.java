package com.viewnext;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.viewnext.models.Alumno;
import com.viewnext.persistence.AlumnosDAO;

@SpringBootApplication
public class Ejemplo2SpringWebFluxApplication implements CommandLineRunner{
	
	@Autowired
	private AlumnosDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo2SpringWebFluxApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Eliminar los datos anteriores
		dao.deleteAll().subscribe();
		
		// Crear una lista con 4 alumnos
		List<Alumno> lista = new LinkedList<>(Arrays.asList(
				new Alumno("Juan", "Lopez", 6.5), 
				new Alumno("Pedro", "Rodriguez", 3.5), 
				new Alumno("Maria", "Sanchez", 9.3), 
				new Alumno("Laura", "Fernandez", 7.8) 
				));
		
		dao.saveAll(lista)
			.subscribe(System.out::println);
		
		System.out.println("------------------------");
		dao.miQuery()
			.doOnNext(System.out::println)
			.subscribe();
		
	}
	
	

}
