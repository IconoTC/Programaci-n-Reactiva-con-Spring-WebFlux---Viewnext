package com.viewnext.persistence;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.viewnext.models.Alumno;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public class AlumnosDAO {
	
	// Crear una lista con 4 alumnos
	List<Alumno> lista = new LinkedList<>(Arrays.asList(
			new Alumno(1, "Juan", "Lopez", 6.5), 
			new Alumno(2, "Pedro", "Rodriguez", 3.5), 
			new Alumno(3, "Maria", "Sanchez", 9.3), 
			new Alumno(4, "Laura", "Fernandez", 7.8) 
			));
	
	public Flux<Alumno> todos(){
		return Flux.fromIterable(lista);
	}
	
	public Mono<Alumno> buscar(int id){
		// Solucion 1
//		return Mono.just(
//				lista.stream()
//					.filter(alum -> alum.getId() == id)
//					.findFirst()
//					.orElse(new Alumno()));
		
		// Solucion 2
		return todos()
				.filter(alum -> alum.getId() == id)
				.singleOrEmpty();
		
	}
	
	public Mono<Alumno> crearNuevo(Alumno nuevo ){
		lista.add(nuevo);
		return Mono.just(nuevo);
	}
	
	public Mono<Void> eliminar(int id){
		lista.removeIf(alum -> alum.getId() == id);
		return Mono.empty();	
	}
	
	public Mono<Alumno> modificar(Alumno alumno ){
		// Solucion 1
//		lista.removeIf(alum -> alum.getId() == alumno.getId());
//		lista.add(alumno);
//		return Mono.just(alumno);
		
		// Solucion 2
		lista.stream()
			.forEach(alum -> {
				if (alum.getId() == alumno.getId()) {
					alum.setNombre(alumno.getNombre());
					alum.setApellido(alumno.getApellido());
					alum.setNota(alumno.getNota());
				}
			});
		return buscar(alumno.getId());
	}

}
