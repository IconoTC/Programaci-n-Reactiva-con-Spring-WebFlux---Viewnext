package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import es.indra.business.IPedidosBS;
import es.indra.models.Pedido;
import reactor.core.publisher.Mono;

@Component
public class HandlerPedidos {
	
	@Autowired
	private IPedidosBS bs;
	
	// http://localhost:8002/crear/2/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	
	public Mono<ServerResponse> crearPedido(ServerRequest request) {
		long id = Long.parseLong(request.pathVariable("id"));
		int cantidad = Integer.parseInt(request.pathVariable("cantidad"));
		
		return bs.crearPedido(id, cantidad)
				.flatMap(pedido -> ServerResponse.ok()
						.contentType(MediaType.APPLICATION_JSON)
						.body(Mono.just(pedido), Pedido.class))
				.switchIfEmpty(ServerResponse.notFound()
				.build());
	}

}
