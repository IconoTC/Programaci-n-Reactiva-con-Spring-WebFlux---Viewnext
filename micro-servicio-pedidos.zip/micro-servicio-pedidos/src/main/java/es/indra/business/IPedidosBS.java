package es.indra.business;

import es.indra.models.Pedido;
import reactor.core.publisher.Mono;

public interface IPedidosBS {
	
	public Mono<Pedido> crearPedido(Long id, int cantidad);

}
