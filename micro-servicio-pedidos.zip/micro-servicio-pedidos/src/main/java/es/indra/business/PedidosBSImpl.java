package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import es.indra.models.Pedido;
import es.indra.models.Producto;
import reactor.core.publisher.Mono;

@Service
@Primary  // Le doy prioridad en la DI
public class PedidosBSImpl implements IPedidosBS{
	
	@Autowired
	private WebClient webClient;

	@Override
	public Mono<Pedido> crearPedido(Long id, int cantidad) {
	
		Mono<Producto> monoProducto = webClient
				.get().uri("/buscar/{id}", id)
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToMono(Producto.class);
		
		Mono<Integer> monoCantidad = Mono.just(cantidad);
		
		Mono<Pedido> monoPedido = monoProducto.flatMap(prod -> monoCantidad.map(c -> new Pedido(prod, c)));
		return monoPedido;
	}

}
