package com.viewnext.persistence;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;

import com.viewnext.models.Alumno;

import reactor.core.publisher.Flux;

// No necesita anotacion al ser un Repository de Spring
public interface AlumnosDAO extends R2dbcRepository<Alumno, Integer>{
	
	@Query("select * from alumnos")
	public Flux<Alumno> miQuery();

}
