package com.viewnext;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;

import com.viewnext.models.Alumno;

@SpringBootApplication
public class Ejemplo2SpringWebFluxApplication implements CommandLineRunner{
	
	@Autowired
	private ReactiveMongoTemplate mongoTemplate;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo2SpringWebFluxApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Borrar los datos anteriores
		//mongoTemplate.dropCollection("alumnos").subscribe();
		
		// Crear una lista con 4 alumnos
		List<Alumno> lista = new LinkedList<>(Arrays.asList(
				new Alumno("Juan", "Lopez", 6.5), 
				new Alumno("Pedro", "Rodriguez", 3.5), 
				new Alumno("Maria", "Sanchez", 9.3), 
				new Alumno("Laura", "Fernandez", 7.8) 
				));
		
		//mongoTemplate.insertAll(lista)
		//	.subscribe(System.out::println);
		
	}

}
