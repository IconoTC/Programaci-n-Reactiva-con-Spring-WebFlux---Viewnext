insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Monitor', 129.50);
insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Teclado', 50.89);
insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Raton', 25.95);
insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Scanner', 230);
insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Pizarra digital', 500);