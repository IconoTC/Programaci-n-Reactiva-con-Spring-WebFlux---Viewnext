package es.indra.business;

import java.util.List;

import es.indra.models.Producto;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface IProductosBS {
	
	Flux<Producto> consultarTodos();
	
	Mono<Producto> buscarProducto(Long id);

}
