package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ProductosBSImpl implements IProductosBS{
	
	@Autowired
	private ProductosDAO dao; // Inyeccion de dependencias DI

	@Override
	public Flux<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Mono<Producto> buscarProducto(Long id) {
		return dao.findById(id);
	}

}
