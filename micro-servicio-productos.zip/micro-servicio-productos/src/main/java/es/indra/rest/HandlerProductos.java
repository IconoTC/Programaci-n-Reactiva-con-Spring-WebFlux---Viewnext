package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import es.indra.business.IProductosBS;
import es.indra.models.Producto;
import reactor.core.publisher.Mono;

@Component
public class HandlerProductos {
	
	@Autowired
	private IProductosBS bs;
	
	public Mono<ServerResponse> todos(ServerRequest request){
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON)
				.body(bs.consultarTodos(), Producto.class);
	}
	
	public Mono<ServerResponse> buscarProducto(ServerRequest request){
		// Comprobar si existe o no ese alumno
		return bs.buscarProducto(Long.parseLong(request.pathVariable("id")))   
				.flatMap(prod -> ServerResponse.ok()
						.contentType(MediaType.APPLICATION_JSON)
						.body(Mono.just(prod), Producto.class))
				.switchIfEmpty(ServerResponse.notFound()
				.build());
	}

}
