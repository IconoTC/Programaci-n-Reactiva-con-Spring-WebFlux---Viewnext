package com.viewnext.persistence;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import com.viewnext.models.Alumno;

import reactor.core.publisher.Mono;

// Cualquier Repository de Spring es un bean (componente manejado de Spring)
// no necesita anotacion y se puede inyectar sin problemas
public interface AlumnosDAO extends ReactiveMongoRepository<Alumno, String>{
	
	// Ademas de los metodos heredados de Repository podemos crear
	// metodos personalizados utilizando keywords
	// https://docs.spring.io/spring-data/mongodb/reference/repositories/query-keywords-reference.html
	
	public Mono<Alumno> findByNombre(String nombre);
	
}
