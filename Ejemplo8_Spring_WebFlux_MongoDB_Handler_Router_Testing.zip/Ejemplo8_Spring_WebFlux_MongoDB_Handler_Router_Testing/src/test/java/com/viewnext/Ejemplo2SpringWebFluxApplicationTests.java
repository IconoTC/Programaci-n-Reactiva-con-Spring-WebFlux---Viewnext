package com.viewnext;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.viewnext.models.Alumno;

import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class Ejemplo2SpringWebFluxApplicationTests {
	
	@Autowired
	private WebTestClient client;

	@Test
	public void todosTest() {
		client.get()
			.uri("/handler/alumnos")
			.accept(MediaType.APPLICATION_JSON)
			.exchange()
			.expectStatus().isOk()
			.expectBodyList(Alumno.class)
			.hasSize(4);
	}
	
	@Test
	public void buscarTest() {
		client.get()
			.uri("/handler/alumnos/{id}", "67e4248a61c4ec5c2a236286")
			.accept(MediaType.APPLICATION_JSON)
			.exchange()
			.expectStatus().isOk()
			.expectBody(Alumno.class)
			.consumeWith(response -> {
				Alumno alumno = response.getResponseBody();
				Assertions.assertThat(alumno.getNombre().equals("Pedro"));
			});
	}
	
	@Test
	public void eliminarTest() {
		client.delete()
			.uri("/handler/alumnos/{id}", "67e4248a61c4ec5c2a236286")
			.accept(MediaType.APPLICATION_JSON)
			.exchange()
			//.expectStatus().isOk()
			.expectStatus().isNoContent()
			.expectBody()
			.isEmpty();
	}
	

	@Test
	public void nuevoTest() {
		Alumno alumno = new Alumno("Pepito", "Perez", 7.3);
		client.post()
			.uri("/handler/alumnos")
			.accept(MediaType.APPLICATION_JSON)
			.body(Mono.just(alumno), Alumno.class)
			.exchange()
			.expectStatus().isOk()
			.expectBody(Alumno.class)
			.consumeWith(response -> {
				Alumno alumnoNuevo = response.getResponseBody();
				Assertions.assertThat(alumnoNuevo.getNombre().equals("Pedro"));
			});
	}
	
	@Test
	public void modificarTest() {
		Alumno alumno = new Alumno("Pedro", "Rodriguez", 3.5);
		alumno.setId("67e4248a61c4ec5c2a236287");
		
		client.put()
			.uri("/handler/alumnos")
			.accept(MediaType.APPLICATION_JSON)
			.body(Mono.just(alumno), Alumno.class)
			.exchange()
			.expectStatus().isOk()
			.expectBody(Alumno.class);
	}

}
